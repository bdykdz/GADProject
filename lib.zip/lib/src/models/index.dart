import 'package:freezed_annotation/freezed_annotation.dart';
part 'news.dart';
part 'app_state.dart';
part 'index.freezed.dart';
part 'index.g.dart';
